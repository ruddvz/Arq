# B10: MCP clients

**State:** Blocked  
**Owner:** AI platform owner

## Why this blocks correctness

This item can change canonical data safety, architecture, interoperability, security, or public claims. It must not be replaced by an assumption.

## Closure action

Client inventory and compatibility suite.

## Minimum evidence

- Revision-bound source or accepted decision.
- Positive and negative tests.
- Failure-path result.
- Rollback or source-retention result.
- Updated claim ledger.
- Reviewer identity and date.

## Not acceptable as closure

A plan, screenshot, generated report, passing isolated test, green build without the required scenario, or unreviewed AI output.
