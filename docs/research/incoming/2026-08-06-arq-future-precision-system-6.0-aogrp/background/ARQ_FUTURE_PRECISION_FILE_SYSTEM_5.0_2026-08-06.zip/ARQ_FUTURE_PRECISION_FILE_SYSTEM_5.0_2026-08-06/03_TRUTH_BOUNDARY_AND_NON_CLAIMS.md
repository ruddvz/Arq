# Truth boundary and non-claims

## Authority order

Current implementation truth belongs to revision-bound repository code, schemas, migrations, tests, CI, deployment artefacts, and directly observed runtime. Accepted ADRs and contracts govern intended architecture. This package is proposal and research material.

## Repository evidence available

The August 4 Operator OS snapshot records repository `ruddvz/Arq`, branch `claude/arq-cad-platform-research-ba8rav`, and observed commit `7f15889ea66b672bd918a8b7ba61a904f6b4da3d`. On August 6, the public GitHub page displayed the same branch and a public README and `STATUS.md`. The authenticated GitHub connector still returned `404`, and current immutable HEAD was not resolved. The August 4 SHA is historical evidence, not a claim about current HEAD.

## Production values intentionally not allocated

- SQLite `application_id`.
- Schema version and migration numbers.
- Canonical codec identifiers.
- Capability namespace ownership.
- Geometry-kernel codec IDs.
- Production object type IDs.
- Accepted error-code ranges.
- File extension registration or MIME type.
- Cryptographic signing policy.

The reference implementation uses an explicitly demo-only application identifier and namespace.

## Non-claims

This package does not claim that `.arq` is currently:

- lossless with DWG, RVT, IFC, STEP, Parasolid, JT, USD, glTF, CityGML, or 3D Tiles;
- deterministic across operating systems or geometry kernels;
- safe against every hostile SQLite or geometry input;
- suitable for aircraft certification, vehicle homologation, structural approval, or manufacturing release;
- synchronised, collaborative, or cloud-backed in production;
- able to design a futuristic city, car, or aircraft today;
- accessible, secure, performant, or released without scoped evidence.

## Required repository reconciliation

ZEUS must resolve immutable HEAD, working tree, open PRs, current `.arq` implementation, accepted ADRs, `CLAUDE.md`, `.zeus/FAST-KERNEL.md`, `.zeus/INVARIANTS.md`, schema allocations, migrations, tests, and delivery stop before implementation.
