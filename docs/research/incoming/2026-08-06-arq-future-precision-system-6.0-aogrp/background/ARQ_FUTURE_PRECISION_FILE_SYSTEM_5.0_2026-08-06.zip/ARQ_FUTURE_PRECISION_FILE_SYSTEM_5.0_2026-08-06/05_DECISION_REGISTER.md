# Decision register

This register distinguishes accepted repository decisions from Version 5.0 proposals.

| ID | Decision | State | Required authority |
|---|---|---|---|
| ARQ5-D01 | SQLite application database remains the candidate portable container | Proposed, aligned with public repo | Accepted repository ADR and implementation evidence |
| ARQ5-D02 | Canonical quantities avoid uncontrolled binary floats | Proposed | Precision ADR and cross-language tests |
| ARQ5-D03 | Deterministic CBOR is the preferred production canonical payload encoding | Proposed | Encoding ADR, pinned library, two independent implementations |
| ARQ5-D04 | JSON is a human-readable projection, not canonical identity bytes | Proposed | Encoding ADR |
| ARQ5-D05 | Geometry kernels are adapters, not semantic authority | Proposed, aligned with repo principles | Geometry ADR and adapter tests |
| ARQ5-D06 | Unknown required capabilities block editable open | Proposed, aligned with current package model | Format ADR and fixtures |
| ARQ5-D07 | Unknown optional data is retained byte-for-byte where the preservation class permits | Proposed | Extension ADR and roundtrip tests |
| ARQ5-D08 | Every accepted operation group creates one immutable revision | Proposed | Operations ADR and repository tests |
| ARQ5-D09 | Merge occurs over semantic records and operations, not SQLite pages or mesh buffers | Proposed | Collaboration ADR |
| ARQ5-D10 | Portable publication is copy-on-write and verified through a fresh reader | Proposed, aligned with public repo | Storage ADR and browser tests |
| ARQ5-D11 | MCP 2026-07-28 is the primary target | Proposed based on current official spec | Repository dependency and compatibility ADR |
| ARQ5-D12 | 2025-11-25 support is a bounded compatibility adapter, not the primary architecture | Proposed | Client inventory and deprecation plan |
| ARQ5-D13 | AI approval binds to an exact proposal digest and revision | Proposed, aligned with ARQ trust boundary | AI ADR and security tests |
| ARQ5-D14 | Architecture remains the first production domain | Existing Project boundary | Repository plan of record |
| ARQ5-D15 | Future domain packs use a registry and ABI instead of modifying core tables ad hoc | Proposed | Extension ADR and plugin threat review |
| ARQ5-D16 | Production identifiers are never allocated by this package | Enforced package rule | Repository owner and ADR process |
