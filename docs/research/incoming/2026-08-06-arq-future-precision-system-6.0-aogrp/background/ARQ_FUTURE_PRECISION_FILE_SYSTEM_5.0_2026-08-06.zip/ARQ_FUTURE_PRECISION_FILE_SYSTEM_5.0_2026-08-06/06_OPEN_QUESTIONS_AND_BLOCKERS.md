# Open questions and unresolved evidence

## Blocked by missing immutable repository inspection

- Current `.arq` application ID, schema layout, migrations, and codecs.
- Current semantic model and typed operation details.
- Current browser SQLite build, OPFS implementation, journal, and save path.
- Current accepted ADR set and any ADR numbering collision.
- Actual MCP package surface and client compatibility.
- Current golden fixtures, fuzzing, CI results, and deployment provenance.

The public repository page provides orientation but does not replace an immutable checkout.

## Architecture questions requiring accepted decisions

- Which store is the canonical working copy, and what role remains for IndexedDB?
- Is deterministic CBOR the canonical operation encoding or an interchange encoding?
- Are exact quantities signed coefficient plus decimal scale, rational values, or domain fixed-point values?
- Is revision identity a semantic state root, an ordered operation log root, or a compound root?
- Which geometry kernel is selected, and how are kernel upgrades isolated?
- Which unknown extension classes may be preserved without interpretation?
- Which collaboration model is acceptable before a backend exists?
- What project-size profile is supported in each browser class?
- Which non-architecture domain is the first verified expansion?

## Proprietary research limits

DWG, RVT, Parasolid, CATIA, SolidWorks, and JT internals and licensing cannot be fully verified from public documents. Any production commitment requires licensed SDK evaluation, legal review, named versions, and roundtrip fixtures.
