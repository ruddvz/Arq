# Research source register

External sources are Class D when current and authoritative for their own standards or products. They do not prove ARQ implementation. Access dates are 5 August 2026 unless otherwise stated.

| Source ID | Authority | Subject | Location | Use |
|---|---|---|---|---|
| EXT-SQLITE-APPFILE | SQLite project | Application-defined file formats | https://sqlite.org/appfileformat.html | Container rationale, application ID, transactional file use |
| EXT-SQLITE-FORMAT | SQLite project | Database and WAL file format | https://sqlite.org/fileformat.html | Sidecars, page structure, recovery boundaries |
| EXT-SQLITE-LIMITS | SQLite project | Implementation limits | https://sqlite.org/limits.html | Hostile-file limits and bounded readers |
| EXT-SQLITE-WASM | SQLite project | WASM and OPFS | https://sqlite.org/wasm/doc/trunk/index.md | Browser storage and worker constraints |
| EXT-MCP-SPEC | MCP project | Protocol specification 2025-11-25 | https://modelcontextprotocol.io/specification/2025-11-25 | Protocol roles and capability negotiation |
| EXT-MCP-AUTH | MCP project | OAuth-based authorization | https://modelcontextprotocol.io/specification/2025-11-25/basic/authorization | Audience binding, PKCE, scopes, token handling |
| EXT-MCP-TOOLS | MCP project | Server tools | https://modelcontextprotocol.io/specification/2025-11-25/server/tools | Tool schemas and trust treatment |
| EXT-MCP-RES | MCP project | Server resources | https://modelcontextprotocol.io/specification/2025-11-25/server/resources | Application-controlled resource exposure |
| EXT-MCP-TASKS | MCP project | Experimental tasks | https://modelcontextprotocol.io/specification/2025-11-25/basic/utilities/tasks | Long-running analysis and isolation requirements |
| EXT-IFC | buildingSMART | IFC 4.3 and release notes | https://technical.buildingsmart.org/standards/ifc/ifc-schema-specifications/ | BIM semantic exchange |
| EXT-MVD | buildingSMART | Model View Definitions | https://technical.buildingsmart.org/standards/ifc/mvd/ | Profile-specific interoperability |
| EXT-IDS | buildingSMART | Information Delivery Specification | https://technical.buildingsmart.org/standards/ids/ | Machine-checkable information requirements |
| EXT-USD | Alliance for OpenUSD | OpenUSD composition | https://openusd.org/release/ | References, payloads, variants, layering |
| EXT-GLTF | Khronos | glTF 2.0 | https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html | Derived visual delivery |
| EXT-3DTILES | OGC/Cesium | 3D Tiles standard | https://www.ogc.org/standard/3dtiles/ | Spatial streaming and LOD |
| EXT-CITYGML | OGC | CityGML 3.0 | https://www.ogc.org/standard/citygml/ | City semantics and levels of detail |
| EXT-CBOR | IETF | RFC 8949 CBOR | https://www.rfc-editor.org/rfc/rfc8949 | Deterministic binary encoding candidate |
| EXT-JCS | IETF | RFC 8785 JSON Canonicalization Scheme | https://www.rfc-editor.org/rfc/rfc8785 | Human-readable deterministic projection |
| EXT-OCCT | Open CASCADE | Modelling algorithms and topology history | https://dev.opencascade.org/doc/overview/html/occt_user_guides__modeling_algos.html | B-Rep capability and kernel adapter research |
| EXT-MANIFOLD | Manifold project | Robust manifold mesh operations | https://github.com/elalish/manifold | Mesh boolean and concept-stage alternative |
| EXT-TRUCK | Truck project | Rust CAD kernel | https://github.com/ricosjp/truck | Rust-native and WASM-oriented kernel research |
| EXT-ONSHAPE | Onshape | Document, version, branch, merge concepts | https://cad.onshape.com/help/Content/Document/document_management.htm | Cloud CAD history and collaboration patterns |
| EXT-ODA-DWG | Open Design Alliance | DWG specification and compatibility | https://www.opendesign.com/files/guestdownloads/OpenDesign_Specification_for_.dwg_files.pdf | Drawing database identity and compatibility lessons |

## Source-use rules

- Exact standard editions and profiles must be recorded in implementation and test evidence.
- Marketing pages are not sufficient for losslessness, safety, or performance claims.
- Proprietary formats require licensed SDK tests before implementation commitments.
- Search snippets are discovery aids. Normative implementation should use the complete official specifications and licences.
