# MCP trust and proposal contract

**Status:** Proposed candidate specification. Not accepted, implemented, verified, or released.

## Purpose

MCP gives AI clients a standard way to discover resources and call tools. ARQ retains authority through scoped grants, revision-pinned resources, typed proposals, deterministic validation, human review, and one-time commit authorisation.

## Normative requirements

- The MCP server MUST negotiate a supported protocol version and expose server capabilities accurately.
- HTTP deployments MUST follow the MCP authorization framework, including protected-resource metadata, audience-bound tokens, secure token handling, PKCE where applicable, and no token passthrough.
- ARQ resources MUST be revision-pinned or explicitly marked live and staleable. Sensitive resources require user-controlled inclusion.
- Tools MUST use JSON Schema 2020-12 input and output contracts and MUST treat annotations and file-derived descriptions as untrusted.
- An ARQ grant MUST bind project, base revision, resource scope, operation types, domain packs, object or spatial scope, limits, export rights, remote-compute rights, expiry, audience, and nonce.
- AI tools MAY create and validate proposals but MUST NOT approve, commit, bypass validation, execute raw SQL, mutate arbitrary files, deploy, or change repository settings.
- Approval MUST bind the exact proposal digest and expire after one use or any proposal change.
- Host commit MUST recheck grant, approval, base revision, operation schemas, permissions, limits, and invariants immediately before transaction.
- MCP tasks for long operations MUST be isolated by authorization context, bounded by TTL and concurrency, cancellable, and audited.

## Required invariants

- Prompt injection through project metadata.
- Replay approval.
- Stale-base proposal.
- Token audience confusion.
- Task ID enumeration.
- Overbroad resource.
- Tool schema drift.
- Model attempts commit bypass.

## Known failure modes

- Technical access is not consent.
- The file cannot enlarge an MCP grant.
- AI proposals use the same canonical operation engine as human commands.
- Approval of one digest cannot authorise a changed proposal.

## Required evidence

- Live client-server protocol tests.
- Grant scope negative tests.
- Approval replay and mutation tests.
- Stale revision tests.
- Authorization-context task isolation.
- Audit reconstruction.

## Implementation guidance

- Keep transport adapter thin and domain service protocol-neutral.
- Return structured diagnostics and proposal previews.
- Use explicit user-facing Review Centre states.
- Do not expose whole project blobs when a bounded resource can answer the task.

## Open decisions

- Supported MCP transports.
- Whether local stdio and remote HTTP share one grant format.

## Non-claims

This document does not prove current repository behaviour, production compatibility, lossless interchange, geometry correctness, security, performance, or release readiness. Those states require revision-bound implementation and executed evidence.
