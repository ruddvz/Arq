# AI, MCP, and CAD automation research

**Status:** Research and proposal input. External sources do not establish current ARQ implementation truth.

## Scope

MCP 2025-11-25 is evaluated as a transport and capability-discovery protocol for AI interaction with ARQ. It is not treated as a design authority, transaction engine, or safety system.

## Verified source observations

- MCP defines hosts, clients, servers, JSON-RPC communication, capability negotiation, resources, prompts, tools, and utilities.
- Resources are application-driven context. Tools are model-callable functions whose schemas and annotations require trust treatment.
- HTTP authorization requires protected-resource discovery, audience-bound tokens, secure token use, PKCE for authorization code flows, and scope management.
- Experimental tasks can represent long-running work but require authorization-context binding, secure IDs, TTL limits, isolation, rate limiting, and audit logs.
- MCP security guidance emphasises explicit user consent, control, privacy, and careful treatment of arbitrary tools and data access.

## Lessons for `.arq`

- Expose revision-pinned read resources and proposal-building tools, never raw SQL or unrestricted file writes.
- Issue ARQ-specific capability grants that bind project, base revision, object scope, operation types, limits, expiry, audience, and nonce.
- Use proposal digests and one-time host approval tokens. A changed proposal invalidates approval.
- Long solver or import tasks may use MCP tasks only when the host can bind task access to the same authorization context.

## Gaps ARQ can address

- ARQ can make AI assumptions, affected objects, downstream regeneration, approximation, and validation visible before commit.
- ARQ can require the same typed operation path for human commands and AI proposals.
- ARQ can preserve model, agent, prompt reference, source revision, tool inputs, approvals, and exact committed operations without storing unnecessary private prompt content.

## Primary sources consulted

- MCP specification, EXT-MCP-SPEC.
- MCP authorization, EXT-MCP-AUTH.
- MCP tools, EXT-MCP-TOOLS.
- MCP resources, EXT-MCP-RES.
- MCP tasks, EXT-MCP-TASKS.

## Limits

- No live MCP client-server run against ARQ was possible.
- The protocol version may evolve; production must negotiate and pin supported versions.
- AI output quality does not replace geometry, domain, or safety validation.
