# ARQ Future Precision File System 4.0

This package is a proposed architecture, conformance system, reference implementation, adversarial audit, and repository handoff for the future `.arq` file format and its surrounding workflows.

Version 4.0 does not claim that ARQ already implements these capabilities. It separates research, proposed contracts, executable demonstrations, and blocked production facts. The current repository could not be fetched through the connected GitHub tool, which returned `404`. Production identifiers, migrations, accepted ADRs, current schemas, and current HEAD therefore remain blocked until repository ZEUS reconciles this package against an immutable revision.

## Why version 4.0 exists

The preceding 3.0 archive made unsupported inventory and validation claims. The actual archive contained 23 files and about 3,020 Markdown words, while its report claimed 214 files, 142 Markdown documents, approximately 35,815 words, 20 schemas, fixtures, tests, and retained background packages. Most claimed artifacts were absent. Version 4.0 treats that discrepancy as a failed evidence event.

Every 4.0 package claim is computed from the finished directory. The package contains its own inventory, SHA-256 manifest, executable tests, fixture verdicts, source register, and validation tool. The final validation report records exactly what was run and what remains blocked.

## Recommended reading order

1. `01_EXECUTIVE_VERDICT.md`
2. `02_VERSION_3_FORENSIC_AUDIT.md`
3. `03_TRUTH_BOUNDARY_AND_NON_CLAIMS.md`
4. `04_SYSTEM_ARCHITECTURE_MAP.md`
5. `normative/00_SCOPE_AND_CONFORMANCE.md`
6. `normative/02_CONTAINER_AND_PUBLICATION.md`
7. `normative/03_CANONICAL_DATA_MODEL.md`
8. `normative/06_OPERATIONS_REVISIONS_UNDO.md`
9. `normative/17_MCP_TRUST_CONTRACT.md`
10. `implementation/04_FIRST_VERTICAL_SLICE.md`
11. `handoff/ZEUS_TASK_HANDOFF.yaml`
12. `VALIDATION_REPORT.md`

## Package truth labels

- **Verified:** proved by an executed package-local check or exact source observation.
- **Partially verified:** some proof exists, but important scope is missing.
- **Proposed:** a candidate design requiring repository acceptance.
- **Inferred:** a reasoned conclusion from identified evidence.
- **Assumed:** an explicit working assumption.
- **Blocked:** required authority or evidence was unavailable.
- **Failed:** a proving check ran and failed.

## Central design position

`.arq` should be a governed precision-project publication, not a single geometry blob and not a loose archive of opaque files. It should preserve semantic intent, exact quantities, typed operations, immutable revisions, deterministic validation, provenance, recoverability, interchange evidence, extension capabilities, and derived representations without making any geometry kernel, renderer, cloud service, or AI agent canonical.
