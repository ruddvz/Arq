# Executive verdict

## Finished result

Version 4.0 defines a coherent candidate system for a future `.arq` format, but it deliberately does not call the system perfect. No file format can be proven best for every future domain before independent implementations, long-term migrations, hostile-input testing, geometry-kernel integration, large-project benchmarks, and real user workflows exist.

The credible goal is stronger: make `.arq` unusually explicit about truth, identity, precision, change, evidence, recovery, interoperability, and AI authority.

## What ARQ should lead on

1. **One accepted semantic state, many derived representations.** Exact B-Rep, meshes, thumbnails, analyses, sheets, and exports remain derived or evidence-bearing representations. They do not silently replace semantic intent.
2. **Exact quantities at the canonical boundary.** Dimensions, units, tolerances, coordinate frames, and constraints cannot depend on uncontrolled binary floating-point serialisation.
3. **Typed, reviewable change.** Every consequential change is an operation group with preconditions, read and write sets, validation, provenance, one revision, and grouped undo.
4. **Truthful interoperability.** Every import and export declares edition, profile, mapping, approximation, omission, source preservation, and roundtrip limits.
5. **Copy-on-write safety.** Save, migration, repair, compaction, and publication create a candidate, validate it, reopen it, and only then promote it.
6. **Stable identity above geometry kernels.** Semantic references must survive regeneration or become explicitly ambiguous. Kernel face indexes and triangle numbers are never permanent identity.
7. **Capability-aware evolution.** Readers negotiate required and optional capabilities, preserve unknown optional data, and refuse unsafe writes.
8. **AI as proposer, never silent authority.** MCP tools expose scoped resources and proposal operations. ARQ validates and commits accepted operations through the same canonical path used by human commands.
9. **Federation instead of giant monoliths.** Buildings, vehicles, aircraft programmes, campuses, and cities can compose pinned child projects and content-addressed assets while retaining local project authority.
10. **Evidence as first-class data.** Validation, analysis, migration, import, export, publication, repair, and approval records name exact inputs, versions, scopes, results, and limitations.

## Highest-risk design areas

- Persistent naming after topology-changing operations.
- Geometry-kernel determinism across platforms and versions.
- Concurrent semantic merge with dependent feature graphs.
- Browser OPFS locking, crash recovery, and sidecar handling.
- Proprietary format compatibility and licensing.
- Migration across years of schemas and extensions.
- Hostile files, decompression bombs, malicious SQLite features, and parser exhaustion.
- AI prompt injection through imported metadata, file names, and external references.
- False confidence from pretty previews or green parser results.

## Delivery decision

Do not rewrite the production format from this package. The next valid delivery stop is repository reconciliation and one narrow vertical slice: read-only preflight, capability reporting, integrity evidence, copy-on-write portable publication, fresh reopen, and source-preserving failure behaviour.
