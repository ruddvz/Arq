# System architecture map

## Authority layers

```text
User intent
  -> ARQ command or reviewed AI proposal
  -> typed operation group
  -> precondition and permission validation
  -> semantic model transaction
  -> invariant validation
  -> immutable revision and grouped undo
  -> dependency regeneration
  -> geometry-kernel execution through adapter
  -> derived meshes, sheets, previews and analyses
  -> publication candidate
  -> integrity, capability and fresh-reader validation
  -> atomic promotion to portable .arq
```

## Canonical data

- Project identity and metadata required to interpret the project.
- Semantic objects and typed components.
- Typed relationships and assembly interfaces.
- Exact quantities, units, tolerances, and coordinate frames.
- Parameters, constraints, features, dependency graphs, and configurations.
- Accepted operation groups, immutable revisions, provenance, and undo boundaries.
- Capability declarations and extension ownership.
- Pinned external references and content-addressed assets.
- Validation and publication evidence that affects trust decisions.

## Derived data

- Kernel-specific B-Rep caches.
- Triangulations and render buffers.
- Spatial indexes.
- Thumbnails and previews.
- Sheet caches.
- Search indexes.
- Solver result visualisations.
- Import and export convenience caches.

Derived data may be discarded and regenerated. Failure to regenerate must not silently alter accepted canonical state.

## External systems

- Geometry kernels calculate shapes but do not own semantic truth.
- Renderers display derived views but do not own model identity.
- Solvers calculate scoped evidence but do not approve design safety.
- Cloud services may compute, collaborate, or back up, but cannot silently become canonical.
- MCP servers expose scoped resources and proposals, not raw file mutation.
