# Repository implementation prompt

Use this package as proposal and evidence input, not as repository authority.

Resolve the ARQ repository, immutable base and head SHA, branch, working-tree state, open pull requests, and requested delivery stop. Read `CLAUDE.md`, then `.zeus/FAST-KERNEL.md`, and comply with `.zeus/INVARIANTS.md` without restating or weakening it. Inspect the current `.arq` file identity, schema, migrations, working database, OPFS or storage path, project-open path, operation engine, MCP code, fixtures, tests, accepted ADRs, and release scope.

First produce a reconciliation report that classifies every material 4.0 proposal as:

- already implemented and verified;
- implemented but unverified;
- compatible proposal;
- conflicting with accepted architecture;
- obsolete;
- blocked by missing decision;
- out of current release scope.

Do not copy package demo identifiers, schema numbers, namespaces, diagnostic ranges, or SQL into production. Allocate values only through repository governance.

Compile the smallest complete vertical slice from `implementation/04_FIRST_VERTICAL_SLICE.md`. Prefer adapting current systems over creating parallel file, invariant, ADR, evidence, language, routing, or release frameworks.

Required implementation properties:

1. Bounded read-only preflight before editable hydration.
2. Structured compatibility state, required capabilities, and stable diagnostics.
3. Copy-on-write portable candidate generated from a transactionally consistent source revision.
4. No dependency on WAL or SHM sidecars in the portable publication.
5. Candidate close, flush, fresh-reader reopen, integrity checks, semantic comparison, and required-asset checks.
6. Atomic destination promotion where supported.
7. Previous source and previous valid destination unchanged on every injected failure.
8. Golden healthy and damaged fixtures.
9. UI states for compatible, preserving read-only, migration, repair, unsupported, corrupt, quarantine, publication progress, and failure.
10. Revision-bound evidence with commands, exit codes, artifacts, platforms, and limitations.

Stop at a reviewed plan unless the user explicitly authorises a later delivery stop. Do not create branches, commits, pull requests, deployments, settings changes, migrations, or production mutations without that authority.
