# MCP server implementation plan

## Architecture

Use two layers:

1. A protocol-neutral ARQ domain service that understands grants, revision-pinned reads, proposals, validation, approval binding, and commit.
2. Thin MCP adapters for local stdio and, only if approved, remote Streamable HTTP with the current MCP authorization framework.

## Resource design

- `arq://project/{project_id}/revision/{revision_id}/summary`
- `arq://project/{project_id}/revision/{revision_id}/objects?scope=...`
- `arq://project/{project_id}/revision/{revision_id}/constraints`
- `arq://project/{project_id}/revision/{revision_id}/diagnostics`
- `arq://project/{project_id}/proposal/{proposal_id}`

Resources must be bounded, typed, revision-pinned, permission-checked, and redact private content.

## Initial tools

- `arq.proposal.begin`
- `arq.proposal.add_operation`
- `arq.proposal.validate`
- `arq.proposal.preview`
- `arq.proposal.submit_review`
- `arq.analysis.request`
- `arq.interchange.preflight`

There is no model-callable `commit`, `approve`, raw SQL, arbitrary file write, shell, deployment, or repository mutation tool.

## Host-only actions

- Issue and revoke grant.
- Display data disclosure.
- Approve exact proposal digest.
- Commit through the operation engine.
- Undo accepted group.
- Export or send external data after explicit user action.

## Required negative tests

- Wrong project, revision, audience, scope, operation type, object scope, expiry, and nonce.
- Proposal changed after approval.
- Approval replay.
- Stale base revision.
- Prompt injection inside resource text.
- Task access across authorization contexts.
- Tool schema mismatch.
- Attempted raw SQL or external write.
