from __future__ import annotations
import hashlib,json,os,sqlite3,subprocess,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def run(cmd):
    p=subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True)
    return {'command':' '.join(map(str,cmd)),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}

def main():
    results=[]
    results.append(run([sys.executable,'-m','unittest','discover','-s','reference/tests','-v']))
    # SQL parse
    con=sqlite3.connect(':memory:')
    try: con.executescript((ROOT/'sql/ARQ_V4_CANDIDATE_LOGICAL_SCHEMA.sql').read_text()); sql='passed'
    finally: con.close()
    # Schemas
    from jsonschema import Draft202012Validator
    schemas=list((ROOT/'schemas').glob('*.json'))
    for p in schemas: Draft202012Validator.check_schema(json.loads(p.read_text()))
    report={'tests':results,'sql_parse':sql,'schema_count':len(schemas),'schema_meta_validation':'passed','python':sys.version,'sqlite':sqlite3.sqlite_version}
    print(json.dumps(report,indent=2)); return 0 if all(x['exit_code']==0 for x in results) else 1
if __name__=='__main__': raise SystemExit(main())
