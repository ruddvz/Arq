# Validation report

**Observed at:** 2026-08-06T03:16:26.134360+00:00

## Completed package-local checks

- Python unit tests discovered and passed: 21.
- JSON Schema Draft 2020-12 meta-validation: passed for 16 schemas.
- Candidate SQLite schema parse in isolated in-memory database: passed.
- Healthy and damaged `.arq` demonstration fixtures generated: 7.
- Copy-on-write publication demonstration: passed.
- Fresh-reader semantic-root comparison: passed.
- Injected publication failure preserved prior destination: passed.
- Wrong application ID rejected: passed.
- Required missing asset rejected: passed.
- Unsupported required capability returned preserving read-only preflight: passed.
- Atomic operation failure preserved prior state: passed.
- Three-way merge conflict classification: passed.
- MCP wrong-audience, stale proposal, exact-proposal commit, mutation-after-approval, and approval replay checks: passed.

## Runtime

- Python: `3.13.5`
- SQLite: `3.46.1`

## Actual package measures before inventory and manifest

- Markdown documents: 72.
- Approximate Markdown words: 20324.
- JSON Schemas: 16.
- `.arq` demonstration fixtures: 7.

## Blocked or not verified

- Current GitHub repository HEAD and production `.arq` implementation were not fetched. Connected GitHub returned `404`.
- Browser OPFS, iOS Safari, mobile publication, multi-tab locking, and storage-pressure behaviour were not executed.
- Deterministic CBOR was not implemented in the demo. The reference uses deterministic JSON with float rejection to test principles without an unpinned dependency.
- No geometry kernel, solver, proprietary format SDK, IFC certification suite, STEP translator, OpenUSD resolver, glTF renderer, CityGML, or 3D Tiles implementation was executed.
- No independent second reader or writer implementation was tested.
- No production application ID, schema number, capability ID, or diagnostic range was allocated.
- No repository code, branch, commit, pull request, deployment, settings, or production file was changed.

## Evidence state

- Package structure and local demonstrations: **Verified** within the listed scope.
- Proposed normative architecture: **Proposed**.
- Fit with current repository: **Blocked** pending immutable HEAD reconciliation.
- Production readiness, security, losslessness, performance, and release: **Not verified**.
