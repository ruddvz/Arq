# Acceptance and review checklist

## Repository truth

- [ ] Repository and immutable HEAD resolved.
- [ ] Worktree and open PRs inspected.
- [ ] `CLAUDE.md`, `.zeus/FAST-KERNEL.md`, and current invariants read.
- [ ] Current application ID, schema, migrations, and fixtures recorded.
- [ ] ADR-0027 collision resolved or explicitly blocked.

## Format safety

- [ ] Preflight has bounded limits and no extension loading.
- [ ] Unknown required capability blocks write.
- [ ] Publication uses a separate candidate.
- [ ] WAL and SHM sidecars are not required by portable file.
- [ ] Fresh reader verifies exact candidate bytes.
- [ ] Source and prior destination survive all forced failures.

## Semantic safety

- [ ] Invalid operation leaves previous canonical state unchanged.
- [ ] Operation group is atomic and creates one revision.
- [ ] Derived caches are excluded from semantic identity.
- [ ] Required assets and references are verified.
- [ ] Stable diagnostics map to UI and tests.

## Product UX

- [ ] File state is understandable without technical expertise.
- [ ] Technical evidence remains inspectable.
- [ ] Read-only mode cannot overwrite source.
- [ ] Progress is phase-based and truthful.
- [ ] Recovery shows project and revision identity.
- [ ] Keyboard and screen-reader flows are tested.

## Evidence

- [ ] Commands and exit codes captured.
- [ ] Fixtures and hashes recorded.
- [ ] Browser and device scope named.
- [ ] Failures and limitations disclosed.
- [ ] No current-tense security, compatibility, or release claim exceeds evidence.
