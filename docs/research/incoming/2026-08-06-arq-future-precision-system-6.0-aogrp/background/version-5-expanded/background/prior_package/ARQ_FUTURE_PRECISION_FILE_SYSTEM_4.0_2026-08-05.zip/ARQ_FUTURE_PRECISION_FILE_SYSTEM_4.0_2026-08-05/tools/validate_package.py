from __future__ import annotations
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def sha(p):
    h=hashlib.sha256();
    with p.open('rb') as f:
        for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
    return h.hexdigest()

def main():
    errors=[]
    inv=json.loads((ROOT/'PACKAGE_INVENTORY.json').read_text())
    actual=[]
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and p.name not in {'PACKAGE_INVENTORY.json','MANIFEST_SHA256.txt'}:
            actual.append({'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
    if actual!=inv['files']: errors.append('inventory mismatch')
    manifest={}
    for line in (ROOT/'MANIFEST_SHA256.txt').read_text().splitlines():
        if line.strip():
            digest,path=line.split('  ',1); manifest[path]=digest
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and p.name!='MANIFEST_SHA256.txt':
            rel=p.relative_to(ROOT).as_posix()
            if manifest.get(rel)!=sha(p): errors.append('manifest mismatch: '+rel)
    print(json.dumps({'state':'verified' if not errors else 'failed','inventory_files':len(actual),'manifest_entries':len(manifest),'errors':errors},indent=2))
    return 0 if not errors else 1
if __name__=='__main__': raise SystemExit(main())
