"""Demo-only ARQ 4.0 reference components.

These modules are package evidence, not production ARQ code.
"""
__version__ = "4.0.0-demo"
