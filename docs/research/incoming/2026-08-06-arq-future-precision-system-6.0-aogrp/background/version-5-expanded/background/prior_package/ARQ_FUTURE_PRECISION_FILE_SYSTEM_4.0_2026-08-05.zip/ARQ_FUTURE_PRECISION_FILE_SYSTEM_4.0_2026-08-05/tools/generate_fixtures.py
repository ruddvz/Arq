from __future__ import annotations
import json,sqlite3,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'reference'))
from arq4.container import create_demo,publish,validate,preflight,ArqFileError

FIX=ROOT/'fixtures'; SCHEMA=ROOT/'sql'/'ARQ_V4_CANDIDATE_LOGICAL_SCHEMA.sql'
healthy=FIX/'healthy_demo.arq'; create_demo(healthy,SCHEMA)
publish(healthy,FIX/'published_demo.arq')
wrong=FIX/'wrong_application_id.arq'; wrong.write_bytes(healthy.read_bytes()); c=sqlite3.connect(wrong); c.execute('PRAGMA application_id=1'); c.close()
trunc=FIX/'truncated.arq'; trunc.write_bytes(healthy.read_bytes()[:512])
future=FIX/'unsupported_required_capability.arq'; future.write_bytes(healthy.read_bytes()); c=sqlite3.connect(future); c.execute("INSERT INTO arq_capability VALUES('arq/future','1.0.0','required','opaque-byte-preserving','future')"); c.commit(); c.close()
asset=FIX/'missing_required_asset.arq'; asset.write_bytes(healthy.read_bytes()); c=sqlite3.connect(asset); c.execute("INSERT INTO arq_asset(asset_id,sha256,media_type,byte_length,role,required,data) VALUES(?,?,?,?,?,?,NULL)",('11111111-1111-4111-8111-111111111111','0'*64,'application/octet-stream',1,'canonical-source',1)); c.commit(); c.close()
rootbad=FIX/'wrong_semantic_root.arq'; rootbad.write_bytes(healthy.read_bytes()); c=sqlite3.connect(rootbad); c.execute("UPDATE arq_publication SET semantic_root=?",('f'*64,)); c.commit(); c.close()

def verdict(path,deep=True):
    try:
        r=validate(path) if deep else preflight(path); return {'state':'accepted','verdict':r.get('verdict'),'code':None}
    except ArqFileError as e: return {'state':'rejected','verdict':None,'code':e.code}
expected={
 'healthy_demo.arq':verdict(healthy),
 'published_demo.arq':verdict(FIX/'published_demo.arq'),
 'wrong_application_id.arq':verdict(wrong),
 'truncated.arq':verdict(trunc),
 'unsupported_required_capability.arq':verdict(future,False),
 'missing_required_asset.arq':verdict(asset),
 'wrong_semantic_root.arq':verdict(rootbad),
}
(FIX/'EXPECTED_VERDICTS.json').write_text(json.dumps(expected,indent=2)+'\n')
print(json.dumps(expected,indent=2))
